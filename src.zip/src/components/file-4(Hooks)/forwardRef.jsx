function ForwardRef(promps){
    return(
    <>
          <input type="text" ref={promps.newRef} />
    </>
    )

}

export default ForwardRef;