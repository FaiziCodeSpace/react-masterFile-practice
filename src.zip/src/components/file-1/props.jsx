function Props({user, routine, children}){
    return(
        <div>
           {children}
        </div>
    )
}

export default Props;