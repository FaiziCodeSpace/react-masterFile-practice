function Page({data}){
    return(
        <div>
            <h1>{data}</h1>
        </div>
    )
}

export default Page;
