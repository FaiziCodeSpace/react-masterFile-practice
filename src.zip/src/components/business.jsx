export default function Business(){
    return(<>
        <h1>Business</h1>
    </>)
}