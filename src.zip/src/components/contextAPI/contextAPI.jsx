import Country from "./country";

export default function ContextAPI(){
    return(<div style={{padding: "20px", background:'orange'}}>
    <Country/>

    

    </div>)
}