import Town from "./town";

export default function City(){
    return(<div style={{padding: "20px", background:'yellow'}}>

    <h1>City</h1>
    <Town/>

    </div>)
}