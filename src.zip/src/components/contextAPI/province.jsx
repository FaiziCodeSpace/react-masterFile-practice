import City from "./city";

export default function Province(){
    return(<div style={{padding: "20px", background:'green'}}>

    <h1>Province</h1>
    <City/>
    
    </div>)
}