import { createContext } from "react";

export const NofBuildings = createContext(0);  