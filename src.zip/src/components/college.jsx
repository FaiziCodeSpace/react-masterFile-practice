export default function College(){
    return(<>
        <h1>College</h1>
    </>)
}