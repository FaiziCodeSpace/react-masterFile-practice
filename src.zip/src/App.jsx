// import Table from "./components/array.jsx";
// import Routine from "./components/checkbox.jsx";
// import Forming from "./components/form.jsx";
// import Info from "./components/information.jsx";
// import RuntimeLoader from "./components/input.jsx";
// import Boards from "./components/output.jsx";
// import GenderProcess from "./components/radio.jsx";
// import Counter from "./components/toggleBtn.jsx";
// import Cc from "./components/color-change";
// import Countries from "./components/country";
// import UseEffect from "./components/useEffect";
// import Style from "./components/styling";
// import External from "./components/ExternalFile";
// import Apping from "./components/functionProms";
// import StyleComponent from "./components/styleComponent";
// import UnControllableComponents from "./components/useref";
// import UseReference from "./components/useref";
// import Testing from "./components/useref2";
// import Form from "./components/useFormState";
// import Parent from "./components/parent";
// import TransitionTest from "./components/useTransitionState";
// import Students from "./components/derivedstate";
// import Component from "./components/ImpureComponents";
// import UseEffect from "./components/file-2/UseEffect.jsx"
// import Array from "./components/array";
// import UseActionState from "./components/file-4(Hooks)/useActionState";
// import Submit from "./components/file-4(Hooks)/useState";
// import Object from "./components/Object";
// import Parent from "./components/parent";
// import Id from "./components/file-4(Hooks)/useid.jsx";
// import Fragment from "./components/fragments.jsx";
// import Fragments from "./components/fragments.jsx";
// import Revision from "./components/revision.jsx";
// import Revision2 from "./components/revision-2.jsx";
// import Browser from "./components/browseRouter.jsx";
// import ContextAPI from "./components/contextAPI/contextAPI.jsx";
// import ShowToggle from "./components/CustomHooks/showCase.jsx";
// import { Routes, Route, Navigate } from "react-router";
// import Navbar from "./components/navbar.jsx";
// import College from "./components/college.jsx";
// import Details from "./components/details.jsx";
// import Business from "./components/business.jsx";
// import Contact from "./components/contactUs.jsx";

import Navbar from "./components/navbar";
import Routers from "./components/routers";


function App(){
    return(
      <>
        {/* <Counter/>
        <Info/>
        <RuntimeLoader/>
        <Forming/>
        <Routine/> 
        <GenderProcess/>
        <Table/>
        <Boards/>
        <Cc/>
        <Countries/>
        <UseEffect/>
        <Style/>
        <External/>
        <StyleComponent/>
        <UseReference/>
        <Testing/>
        <UnControllableComponents/>
        <Apping/>
        <Parent/>
        <Form/>
        <TransitionTest/>
        <Component/>
        <Students/>
        <Parent/>
        <Object/>
        <Array/>
        <Submit/>
        <UseActionState/>
        <Id/>
        <Fragments/>
        <h1 className='header'>Hello there</h1> 
        <Revision2/>
        <Revision/>
        <ShowToggle/>
        <ContextAPI/>
        <Browser/>*/}
        <Routers/>
      </>
    )
}

export default App;